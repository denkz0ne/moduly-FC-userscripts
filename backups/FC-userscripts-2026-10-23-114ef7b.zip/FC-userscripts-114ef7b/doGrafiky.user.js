// ==UserScript==
// @name         Do grafiky
// @namespace    faxcopy-userscripts
// @author       mato e.
// @version      3.7
// @description  DO GRAFIKY -> oznaci ZaPoGRAF a zaradi VP do CG_Grafik - Grafika bez modalov a klikania
// @updateURL    https://github.com/denkz0ne/moduly-FC-userscripts/raw/main/doGrafiky.user.js
// @downloadURL  https://github.com/denkz0ne/moduly-FC-userscripts/raw/main/doGrafiky.user.js
// @match        https://moduly.faxcopy.sk/vyrobne_prikazy/detail/index/*
// @run-at       document-end
// ==/UserScript==
// FC Userscripts ecosystem: https://github.com/denkz0ne/moduly-FC-userscripts

(function () {
    'use strict';

    const GRAFIKA_VF_ID = '301';
    const ZAPOGRAF_TAG_ID = '602';
    const BUTTON_ID = 'doGrafikyBtn';
    const GRAFIKA_RIGHT_OFFSET = '235px';
    const DEFAULT_LABEL = ' do GRAFIKY';

    function getVpId() {
        const match = window.location.pathname.match(/\/detail\/index\/(\d+)/);
        if (!match) {
            throw new Error('Nepodarilo sa zistit ID VP z URL.');
        }

        return match[1];
    }

    function buildSerializedVp(vpId) {
        return `a:1:{i:0;s:${vpId.length}:"${vpId}";}`;
    }

    function sleep(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }

    function showToast(message, type = 'success') {
        const existingToast = document.getElementById('doGrafikyToast');
        if (existingToast) {
            existingToast.remove();
        }

        const toast = document.createElement('div');
        toast.id = 'doGrafikyToast';
        toast.textContent = message;
        toast.style.position = 'fixed';
        toast.style.top = '20px';
        toast.style.right = '20px';
        toast.style.zIndex = '99999';
        toast.style.padding = '12px 16px';
        toast.style.borderRadius = '8px';
        toast.style.color = '#fff';
        toast.style.fontSize = '14px';
        toast.style.fontWeight = '600';
        toast.style.boxShadow = '0 10px 25px rgba(0, 0, 0, 0.25)';
        toast.style.background = type === 'success' ? '#2e7d32' : '#c62828';

        document.body.appendChild(toast);

        setTimeout(() => {
            toast.remove();
        }, 3500);
    }

    async function postForm(url, params, ajax = false) {
        const headers = {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
        };

        if (ajax) {
            headers['X-Requested-With'] = 'XMLHttpRequest';
        }

        const response = await fetch(url, {
            method: 'POST',
            credentials: 'include',
            headers,
            body: new URLSearchParams(params).toString(),
            redirect: 'follow'
        });

        if (!response.ok) {
            throw new Error(`Request zlyhal: ${response.status} ${response.statusText}`.trim());
        }

        return response;
    }

    async function setGrafikaTag(vpId) {
        await postForm('/vyrobne_prikazy/tags/saveCartTags', {
            id: ZAPOGRAF_TAG_ID,
            vpId,
            selected: '1'
        }, true);
    }

    async function assignToGrafikaQueue(vpId) {
        await postForm('/vyrobne_prikazy/industrialQueue', {
            'VF[]': GRAFIKA_VF_ID,
            VP_ID_PRODUCTION_STATUS: '',
            STAV_OBJEDNAVKY: '',
            VP: buildSerializedVp(vpId),
            id: vpId,
            save: 'Zaradiť',
            _form_: 'industrialVPForm'
        });
    }

    function setButtonState(button, label, busy) {
        const textNode = button.querySelector('.do-grafiky-label');
        if (textNode) {
            textNode.textContent = label;
        }

        button.style.pointerEvents = busy ? 'none' : 'auto';
        button.style.opacity = busy ? '0.6' : '1';
    }

    function createButton(vfButton) {
        if (document.getElementById(BUTTON_ID)) {
            return;
        }

        const button = document.createElement('a');
        button.id = BUTTON_ID;
        button.href = '#';
        button.className = vfButton.className;
        button.innerHTML = `<img src="/assets/img/icons/checkbox-white.png" alt=""><span class="do-grafiky-label">${DEFAULT_LABEL}</span>`;
        button.title = 'do GRAFIKY';
        button.style.right = GRAFIKA_RIGHT_OFFSET;
        button.style.background = '#7b1fa2';
        button.style.borderColor = '#6a1b9a';
        button.style.cursor = 'pointer';
        button.style.whiteSpace = 'nowrap';
        button.style.width = 'auto';
        button.style.minWidth = '118px';
        button.style.textAlign = 'center';
        button.style.boxSizing = 'border-box';

        button.addEventListener('click', async (event) => {
            event.preventDefault();
            event.stopPropagation();
            event.stopImmediatePropagation();

            try {
                const vpId = getVpId();

                setButtonState(button, 'SPRACOVAVAM...', true);
                console.log('[DO GRAFIKY] Startujem request-based flow pre VP', vpId);

                await setGrafikaTag(vpId);
                await assignToGrafikaQueue(vpId);

                setButtonState(button, 'HOTOVO', true);
                showToast('VP bolo uspesne zaradene do grafiky.');
                console.log('[DO GRAFIKY] VP uspesne zaradene do grafiky.');

                await sleep(1400);
                window.location.reload();
            } catch (error) {
                console.error('[DO GRAFIKY] Chyba:', error);
                setButtonState(button, DEFAULT_LABEL, false);
                showToast(`DO GRAFIKY zlyhalo: ${error.message}`, 'error');
            }
        }, true);

        vfButton.parentNode.insertBefore(button, vfButton);
        console.log('[DO GRAFIKY] Button pridany do povodneho radu akcii bez zasahu do layoutu webu.');
    }

    function init() {
        let tries = 0;

        const interval = setInterval(() => {
            tries += 1;

            const vfButton = [...document.querySelectorAll('a.datatable-add.button.green.small')]
                .find((button) => (button.getAttribute('onclick') || '').includes('showVpSingleForm('));

            if (vfButton) {
                clearInterval(interval);
                createButton(vfButton);
                return;
            }

            if (tries > 30) {
                clearInterval(interval);
            }
        }, 1000);
    }

    window.addEventListener('load', init);
})();
